<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation \Request;

use Symfony\Component\Form \Extension\Core\Type\TextType ;
use Symfony\Component\Form \Extension\Core\Type\TextareaType ;
use Symfony\Component\ Form\Extension\Core\Type \DateTimeType;
use Symfony\ Component\Form\Extension\Core \Type\ChoiceType;
use  Symfony\Component\Form\Extension \Core\Type\SubmitType;
use App\Entity\Event ;

class EventController extends AbstractController
{
    /**
     * @Route("/", name="home_page")
     */
    public function showAction()
    {
        $events = $this->getDoctrine()->getRepository( 'App:Event')->findAll();
     
        return $this ->render('event/index.html.twig', array('events'=>$events));
    }

    /**
    * @Route("/create", name="create_page")
    */
    public function  createAction(Request $request)
   {
        // Here we create an object from the class that we made
       $event = new Event;
/* Here we will build a form using createFormBuilder and inside this function we will put our object and then we write add then we select the input type then an array to add an attribute that we want in our input field */
       $form = $this->createFormBuilder($event)->add( 'name', TextType::class, array ('attr' => array ('class'=> 'form-control' , 'style'=> 'margin-bottom:15px')))
       ->add( 'capacity', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
       ->add( 'address', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
       ->add( 'image', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
       ->add( 'email', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
       ->add( 'description', TextareaType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px' )))
       ->add( 'type' , ChoiceType::class, array ( 'choices' => array ( 'Music' => 'Music' , 'Theater' => 'Theater' , 'Sport' => 'Sport' ), 'attr'  => array ( 'class' => 'form-control' , 'style' => 'margin-botton:15px' )))
       ->add( 'phonenumber', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
   ->add( 'eventdate' , DateTimeType::class, array ( 'attr'  => array ( 'style' => 'margin-bottom:15px' )))
   ->add( 'url', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
   ->add( 'save' , SubmitType::class, array ( 'label' => 'Create Event' , 'attr'  => array ( 'class' => 'btn-danger' , 'style' => 'margin-bottom:15px' )))
       ->getForm();
       $form->handleRequest($request);
       

        /* Here we have an if statement, if we click submit and if  the form is valid we will take the values from the form and we will save them in the new variables */
        if ($form->isSubmitted() && $form->isValid()){
            //fetching data

            // taking the data from the inputs by the name of the inputs then getData() function
           $name = $form[ 'name' ]->getData();
           $capacity = $form[ 'capacity' ]->getData();
           $address = $form[ 'address' ]->getData();
           $image = $form[ 'image' ]->getData();
           $email = $form[ 'email' ]->getData();
           $description = $form[ 'description' ]->getData();
           $type = $form[ 'type' ]->getData();
           $phonenumber = $form[ 'phonenumber' ]->getData();
           $eventdate = $form[ 'eventdate' ]->getData();
           $url = $form[ 'url' ]->getData();
           
            // Here we will get the current date
           $now = new \DateTime( 'now' );

/* these functions we bring from our entities, every column have a set function and we put the value that we get from the form */
           $event->setName($name);
           $event->setCapacity($capacity);
           $event->setAddress($address);
           $event->setImage($image);
           $event->setEmail($email);
           $event->setDescription($description);
           $event->setType($type);
           $event->setPhonenumber($phonenumber);
           $event->setEventdate($eventdate);
           $event->setUrl($url);
           $em = $this ->getDoctrine()->getManager();
           $em->persist($event);
           $em->flush();
            $this ->addFlash(
                    'notice' ,
                    'Event Added'
                   );
            return   $this ->redirectToRoute( 'home_page' );
       }
/* now to make the form we will add this line form->createView() and now you can see the form in create.html.twig file  */
        return   $this ->render( 'event/create.html.twig' , array ( 'form'  => $form->createView()));
   }

   /**
    * @Route("/details/{id}", name="details_page")
    */
    public function  detailsAction($id)
    {
        $event = $this->getDoctrine()->getRepository( 'App:Event')->find($id);
        return $this->render( 'event/details.html.twig', array('event' => $event));
    }

     /**
    * @Route("/edit/{id}", name="edit_page")
    */
    public  function editAction( $id, Request $request)
   {
    $event = $this->getDoctrine()->getRepository('App:Event')->find($id);
    $event->setName($event->getName());
    $event->setCapacity($event->getCapacity());
    $event->setAddress($event->getAddress());
    $event->setImage($event->getImage());
    $event->setEmail($event->getEmail());
    $event->setDescription($event->getDescription());
    $event->setType($event->getType());
    $event->setPhonenumber($event->getPhonenumber());
    $event->setEventdate($event->getEventdate());
    $event->setUrl($event->getUrl());
    
  
   
    /* Here we will build a form using createFormBuilder and inside this function we will put our object and then we write add then we select the input type then an array to add an attribute that we want in our input field */
    $form = $this->createFormBuilder($event)->add( 'name', TextType::class, array ('attr' => array ('class'=> 'form-control' , 'style'=> 'margin-bottom:15px')))
    ->add( 'capacity', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
    ->add( 'address', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
    ->add( 'image', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
    ->add( 'email', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
    ->add( 'description', TextareaType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px' )))
    ->add( 'type' , ChoiceType::class, array ( 'choices' => array ( 'Music' => 'Music' , 'Theater' => 'Theater' , 'Sport' => 'Sport' ), 'attr'  => array ( 'class' => 'form-control' , 'style' => 'margin-botton:15px' )))
    ->add( 'phonenumber', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
->add( 'eventdate' , DateTimeType::class, array ( 'attr'  => array ( 'style' => 'margin-bottom:15px' )))
->add( 'url', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
->add( 'save' , SubmitType::class, array ( 'label' => 'Edit event' , 'attr'  => array ( 'class' => 'btn-primary' , 'style' => 'margin-bottom:15px' )))
    ->getForm();
           $form->handleRequest($request);
           
    
            /* Here we have an if statement, if we click submit and if  the form is valid we will take the values from the form and we will save them in the new variables */
            if ($form->isSubmitted() && $form->isValid()){
                //fetching data
    
                // taking the data from the inputs by the name of the inputs then getData() function
               $name = $form[ 'name' ]->getData();
               $capacity = $form[ 'capacity' ]->getData();
               $address = $form[ 'address' ]->getData();
               $image = $form[ 'image' ]->getData();
               $email = $form[ 'email' ]->getData();
               $description = $form[ 'description' ]->getData();
               $type = $form[ 'type' ]->getData();
               $phonenumber = $form['phonenumber']->getData();
               $eventdate = $form[ 'eventdate' ]->getData();
               $url = $form[ 'url' ]->getData();
               
                // Here we will get the current date
             
    
    /* these functions we bring from our entities, every column have a set function and we put the value that we get from the form */
               $event->setName($name);
               $event->setCapacity($capacity);
               $event->setAddress($address);
               $event->setImage($image);
               $event->setEmail($email);
               $event->setDescription($description);
               $event->setType($type);
               $event->setPhonenumber($phonenumber);
               $event->setEventdate($eventdate);
               $event->setUrl($url);
               
               $em = $this ->getDoctrine()->getManager();
               $em->persist($event);
              
               $em->flush();
               $this->addFlash(
                       'notice',
                       'Event Updated'
                      );
               return $this ->redirectToRoute('home_page' );
          }
          return  $this->render( 'event/edit.html.twig', array( 'event' => $event, 'form' => $form->createView()));      
}
    /**
    * @Route("/delete/{id}", name="todo_delete")
    */
    public function deleteAction($id){
        $em = $this->getDoctrine()->getManager();
   $event = $em->getRepository('App:Event')->find($id);
   $em->remove($event);
    $em->flush();
    $this->addFlash(
           'notice',
            'Event Removed'
           );
           
    return  $this->redirectToRoute('home_page');
}

  
      }

